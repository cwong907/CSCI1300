#include "Pokemon.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <vector>
#include <math.h>

using namespace std;

Pokemon::Pokemon()
{
    pokemonName = "";
    hp = 0;
    attack = 0;
    defense = 0;
    speed = 0;
    max = 0;
    level = 0;
}
    
void Pokemon::readPokemonFile(string)
{
    /*
    This reads the the pokemon file and fills the pokemon vector with every pokemon
    */
}
    
void Pokemon::setPokemonName(string pokename)
{
    pokemonName = pokename;
}

void Pokemon::setHp(int h)
{
    hp = h;
}

void Pokemon::setAttack(int a)
{
    attack = a;
}

void Pokemon::setDefense(int d)
{
    defense = d;
}

void Pokemon::setSpeed(int s)
{
    speed = s;
}

void Pokemon::setMax(int m)
{
    max = m;
}

void Pokemon::setLevel(int l)
{
    level = l;
}

void Pokemon::setType(int index)
{
    /*
    This function takes the the types from the pokemon file and then pushes it into the types vector at the corresponding index to the pokemon vector 
    */
}
    
string Pokemon::getPokemonName(string name)
{
    return pokemonName;
}

vector<string> Pokemon::getTypeAt(int)
{
    /*
    Based on an int index that corresponds to the pokemon in the pokemon vector, this goes into the types vector to retrieve the pokemon type
    */
}

int Pokemon::getHp()
{
    return hp;
}

int Pokemon::getAttack()
{
    return attack;
}

int Pokemon::getDefense()
{
    return defense;
}

int Pokemon::getSpeed()
{
    return speed;
}

int Pokemon::getMax()
{
    return max;
}

int Pokemon::getLevel()
{
    return level;
}