#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <vector>
#include <cmath>
#include "Player.h"
#include "Pokemon.h"
#include "Battles.h"
#include "Map.h"
#include "gameManager.h"

using namespace std;

int main()
{
    string username;
    
    cout << "Welcome to Pokémon!" << endl;
    cout << endl;
    
    cout << "Please state your name:" << endl;
    getline(cin, username);
    cout << endl;
    Player myPlayer.setUsername(username);
    
    cout << "Welcome, " << username << "! " << "Before you can begin your Pokémon adventure, you must choose a starting Pokémon, courtesy of the Professor." << endl;
    cout << endl;
    cout << "Please choose from the following Pokémon:" << endl;
    cout << "1. Bulbasaur" << endl;
    cout << "2. Charmander" << endl;
    cout << "3. Squirtle" << endl;
    cout << "4. Pikachu" << endl;
    
    /*
    From here it calls the startGame() function to initialize the game
    Goes through the "main menu" (basically the one that moves, rests, etc)
    Goes into the battles menu if the situation requires
    */
}