#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <vector>
#include <cmath>
#include "Pokemon.h"
#ifndef POKEMON_H
#define POKEMON_H

using namespace std;

class map
{
    private:
    char map[25][16];
    vector<Pokemon> 
    
    public:
    Map();
    
    void readMap(string);
    char printMap();
    char printVisible();
};
#endif