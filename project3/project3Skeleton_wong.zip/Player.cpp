#include "Player.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <vector>

using namespace std;

Player::Player()
{
    username = "";
    pokeball = 0;
    badges = 0;
    points = 0;
    numPokemon = 0;
}

void Player::setUsername(string n)
{
    username = n;
}

void Player::setPlayerX(int x)
{
    playerLocationX = x;
}

void Player::setPlayerY(int y)
{
    playerLocationY = y;
}

void Player::switchActivePokemon()
{
    /*
    When selected the function gets and displays the vector<Pokemon> playerPokemon vector so they can see all their current pokemon stored (it is only prompted when a fight occurs)
    Then it asks which one of the ones presented to become the active pokemon
    After the user selects the pokemon it pushs back into vector<Pokemon> active to declare it
    
    */
}

void Player::updatePokedex();
{
    /*
    When a pokemon is caught, it searches through the vector <Pokemon> allPokemon until it finds the pokemon and pushes it back into the playerPokedex vector so it's a new pokemon
    */
}

string getUsername();
{
    return username;
}

int getNumPokemon();
{
    return numPokemon;
}

int getBadges();
{
    return badges;
}

int getPoints();
{
    return points;
}

int getPokeball();
{
    return pokeball;
}

int getplayerLocationX();
{
    return playerLocationX;
}

int getPlayerLocationY();
{
    return playerLocationY;
}
