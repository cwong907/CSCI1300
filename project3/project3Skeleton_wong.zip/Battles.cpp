#include "Battles.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <vector>
#include <math.h>

using namespace std;

void Battles::battleWildTracker()
{
    /*
    When called on, this function displays the options for fighting wild pokemon encountered in the world
    Depending on the option the user selects, the function runs fight, switch active pokemon, or run and outputs the corresponding things
    The function also will keep track of the index of the 2D array so that pokemon battles aren't repeated
    */
}

int Battles::getXLocation()
{
    return xTLocation[0];
}

int Battles::getYLocation()
{
    return yTLocation[0];
}

string Battles::getTrainerName()
{
    return trainerName;
}