#include "gameManager.h"
#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <vector>
#include <math.h>

using namespace std;

void gameManager::pokemonScatter()
{
    /*
    Using the rand function, the function will randomly select 20 numbers between 1 and 150 and store them. The numbers represent the index of the pokemon in a pokemon vecotr that holds every one
    Then it will randomly pick 20 spots within the 2D array and assign the spots to the pokemon index as it does that
    The locations will be stored so the game knows where the pokemon are
    */
}

void gameManager::trainerScatter()
{
    /*
    Looks at each location where there is a G on the map and assigns a trainer to that location
    */
}

void gameManager::updatePlayerPosition(int, int)
{
    /*
    Is initialized when the player picks a started pokemon in the form of the coordinates on the 2D array
    Adds or subtracts one from the coordinates and updates the variables
    */
}

void gameManager::startGame(string)
{
    /*
    Reads the pokemon file and populates the pokemon vector with pokemon objects for every pokemon
    Reads the map file and populates the 2D array with the file contents
    Initializes the start of the game up till the pokemon selection
    */
}

void gameManager::turns()
{
    /*
    Loops through and calls on functions that are responsible for things other than battles
    Presents the options to travel, rest, try your luck, and quit
    Based on what the player selects, the function will run that until some external condition forces it to do other wise(like a battle for example)
    */
}
