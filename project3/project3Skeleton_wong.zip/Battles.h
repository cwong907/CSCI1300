#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <vector>
#include <cmath>
#include "Pokemon.h"
#ifndef BATTLES_H
#define BATTLES_H

using namespace std;

class battles
{
    private:
    string trainerName;
    vector<Pokemon> trainerPokemons;
    vector<int> xTLocation;
    vector<int> yTLocation;
    
    public:    
    void battleWildTracker();
    void battleTrainerTracker();
    vector<int> getXLocation();
    vector<int> getYLocation();
    string getTrainerName();
    
};
#endif