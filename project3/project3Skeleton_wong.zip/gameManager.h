#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <vector>
#include <cmath>
#ifndef GAMEMANAGER_H
#define GAMEMANAGER_H

using namespace std;

class gameManager
{
    private:
    vector <Pokemon> allPokemon;
    
    public:
    void pokemonScatter();
    void trainerScatter();
    void updatePlayerPosition(int, int);
    void startGame(string);
    void turns();
};
#endif