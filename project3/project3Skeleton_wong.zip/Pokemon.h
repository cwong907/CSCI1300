#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <vector>
#include <cmath>
#ifndef POKEMON_H
#define POKEMON_H

using namespace std;

class pokemon
{
    private:
    string pokemonName;
    vector<string> types;
    int hp;
    int attack;
    int defense;
    int speed;
    int max;
    int level;
    vector<int> xPLocation;
    vector<int> yPLocation;
    
    public:
    Pokemon();
    
    void readPokemonFile(string);
    
    void setPokemonName(string);
    void setHp(int);
    void setAttack(int);
    void setDefense(int);
    void setSpeed(int);
    void setMax(int);
    void setLevel(int);
    void setType(string);
    
    string getPokemonName();
    vector<string> getTypeAt(int);
    int getHp();
    int getAttack();
    int getDefense();
    int getSpeed();
    int getMax();
    int getLevel();
    
};
#endif