// CSCI 1300 Fall 2019
// Author: Weige Wong
// Recitation: 203 - Soumyajyoti Bhattacharya
//Homework 2 - Question 1


#include <iostream>
using namespace std;

/*
1. Write a program that says, "Hello World!" to the console.
2. Then run the program from the bash tab.
Input: None
Output: Hello, World!
Return: None
*/

int main ()
{
    cout << "Hello, World!" << endl; // Have "Hello World!" be sent out to the console.
    
}